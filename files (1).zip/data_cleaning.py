"""
ShopEase Raw Orders Dataset - Cleaning Module
Group ID: 095_105_107_109
"""
import pandas as pd
import numpy as np

CANON_CATEGORY = ['Electronics', 'Fashion', 'Beauty', 'Sports', 'Home']
CANON_CITY = ['Cairo', 'Giza', 'Alexandria', 'Mansoura', 'Tanta', 'Aswan']
CANON_PAYMENT = ['Cash', 'Visa', 'Wallet', 'Mastercard', 'Bank Transfer']
CANON_STATUS = ['Delivered', 'Pending', 'Cancelled']


def _norm_categorical(series, canon_list):
    s = series.astype(str).str.strip().str.title()
    s = s.replace({'Canceled': 'Cancelled'})
    lookup = {c.title(): c for c in canon_list}
    return s.map(lambda x: lookup.get(x, x))


def _parse_mixed_dates(series):
    def parse_one(v):
        if pd.isna(v):
            return pd.NaT
        v = str(v).strip()
        for fmt in ('%Y-%m-%d %H:%M:%S', '%d-%m-%Y', '%Y-%m-%d', '%d/%m/%Y'):
            try:
                return pd.to_datetime(v, format=fmt)
            except (ValueError, TypeError):
                continue
        return pd.to_datetime(v, errors='coerce', dayfirst=True)
    return series.apply(parse_one)


def _parse_discount(series):
    def parse_one(v):
        if pd.isna(v):
            return np.nan
        v = str(v).strip()
        if v.endswith('%'):
            return float(v[:-1]) / 100.0
        return float(v)
    return series.apply(parse_one)


def clean_shopease(raw_path):
    df = pd.read_csv(raw_path)
    n_raw = len(df)
    log = {'n_raw_rows': n_raw, 'n_raw_cols': df.shape[1]}

    # 1. Drop exact full-row duplicates
    n_dup = df.duplicated().sum()
    df = df.drop_duplicates().reset_index(drop=True)
    log['exact_duplicate_rows_dropped'] = int(n_dup)

    # 2. CustomerID / Product - fill missing text with 'Unknown'
    df['CustomerID'] = df['CustomerID'].fillna('Unknown').str.strip()
    log['missing_customerid'] = int(df['CustomerID'].eq('Unknown').sum())
    df['Product'] = df['Product'].fillna('Unknown').astype(str).str.strip().str.title()
    log['missing_product'] = int(df['Product'].eq('Unknown').sum())

    # 3. Dates
    df['OrderDate'] = _parse_mixed_dates(df['OrderDate'])
    df['DeliveryDate'] = _parse_mixed_dates(df['DeliveryDate'])

    # 4. CustomerAge - invalid (<0 or >100) -> NaN -> median impute
    invalid_age = (df['CustomerAge'] < 0) | (df['CustomerAge'] > 100)
    log['invalid_age_rows'] = int(invalid_age.sum())
    log['missing_age_original'] = int(df['CustomerAge'].isna().sum())
    df.loc[invalid_age, 'CustomerAge'] = np.nan
    age_median = df['CustomerAge'].median()
    df['CustomerAge'] = df['CustomerAge'].fillna(age_median)
    log['age_median_used_for_impute'] = float(age_median)

    # 5. Gender
    g = df['Gender'].astype(str).str.strip().str.upper()
    df['Gender'] = g.map(lambda x: 'Male' if x in ('M', 'MALE') else ('Female' if x in ('F', 'FEMALE') else x.title()))

    # 6. City, Category, PaymentMethod, OrderStatus - normalize case/whitespace
    df['City'] = _norm_categorical(df['City'], CANON_CITY)
    df['Category'] = _norm_categorical(df['Category'], CANON_CATEGORY)
    df['PaymentMethod'] = _norm_categorical(df['PaymentMethod'], CANON_PAYMENT)
    log['missing_payment_method'] = int(df['PaymentMethod'].isna().sum())
    df['PaymentMethod'] = df['PaymentMethod'].fillna('Unknown')
    df['OrderStatus'] = _norm_categorical(df['OrderStatus'], CANON_STATUS)

    # 7. Quantity - negative -> abs; zero -> drop (invalid order)
    n_neg_qty = (df['Quantity'] < 0).sum()
    df['Quantity'] = df['Quantity'].abs()
    n_zero_qty = (df['Quantity'] == 0).sum()
    df = df[df['Quantity'] != 0].reset_index(drop=True)
    log['negative_qty_fixed'] = int(n_neg_qty)
    log['zero_qty_rows_dropped'] = int(n_zero_qty)

    # 8. Discount - parse % strings -> decimal; missing -> 0 (mode / no discount)
    df['Discount'] = _parse_discount(df['Discount'])
    log['missing_discount'] = int(df['Discount'].isna().sum())
    df['Discount'] = df['Discount'].fillna(0.0)
    df['Discount'] = df['Discount'].clip(0, 1)

    # 9. UnitPrice - negative -> abs; extreme outliers vs product median -> replace with product median
    n_neg_price = (df['UnitPrice'] < 0).sum()
    df['UnitPrice'] = df['UnitPrice'].abs()
    prod_median_price = df.groupby('Product')['UnitPrice'].transform('median')
    is_outlier_price = df['UnitPrice'] > (prod_median_price * 5)
    log['negative_price_fixed'] = int(n_neg_price)
    log['outlier_price_rows_fixed'] = int(is_outlier_price.sum())
    df.loc[is_outlier_price, 'UnitPrice'] = prod_median_price[is_outlier_price]

    # 10. Rating - out-of-range values -> NaN (1-5 valid scale); leave NaN as-is
    #     (missing/NaN Rating is STRUCTURAL: only Delivered orders are rated)
    invalid_rating = df['Rating'].notna() & (~df['Rating'].isin([1, 2, 3, 4, 5]))
    log['invalid_rating_values_nulled'] = int(invalid_rating.sum())
    df.loc[invalid_rating, 'Rating'] = np.nan

    # 11. Recompute a consistency-checked TotalAmount from cleaned fields
    df['TotalAmount_raw'] = df['TotalAmount']
    df['TotalAmount'] = (df['UnitPrice'] * df['Quantity'] * (1 - df['Discount'])).round(2)

    # 12. Derived fields useful for analysis
    df['DeliveryDays'] = (df['DeliveryDate'] - df['OrderDate']).dt.total_seconds() / 86400.0
    df['OrderMonth'] = df['OrderDate'].dt.to_period('M').astype(str)
    df['IsDelivered'] = (df['OrderStatus'] == 'Delivered').astype(int)
    df['HighRating'] = pd.Series(np.where(df['Rating'] >= 4, 1, 0), index=df.index).astype('Int64')
    df.loc[df['Rating'].isna(), 'HighRating'] = pd.NA

    log['n_clean_rows'] = len(df)
    log['n_clean_cols'] = df.shape[1]
    return df, log


if __name__ == '__main__':
    df, log = clean_shopease('/mnt/user-data/uploads/shopease_raw_orders.csv')
    import json
    print(json.dumps(log, indent=2))
    print(df.dtypes)
    print(df.isna().sum())
