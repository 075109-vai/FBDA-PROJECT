# FBDA Project — ShopEase Dynamic Analytical Dashboard
Group ID: 095_105_107_109 | Seed: 95105107109
Prakriti Sharma (075095) · Shreyash Satpathy (075105) · Sushant (075107) · Vaibhav Pratap Singh (075109)

## Files
- `FBDA_2026_Project_ShopEase.ipynb` — **main deliverable**: full report + code + real results, per the required
  report format (sections 1–8). Open in Google Colab (upload this file, plus `shopease_raw_orders.csv`,
  `shopease_sample_2500.csv`, `stats_helpers.py`, and the `figures/` folder to the Colab session, or to Drive).
- `app.py` — Streamlit dashboard (Task 1, 50%). Self-contained: cleans + samples data itself.
- `shopease_raw_orders.csv` — original raw dataset (as uploaded).
- `shopease_sample_2500.csv` — cleaned, fixed-seed 2,500-record sample used throughout the analysis.
- `data_cleaning.py` — reusable cleaning module (used by the notebook).
- `stats_helpers.py` — manual OLS/Logistic regression (statsmodels replacement, same statistical formulas).
- `figures/` — all chart PNGs (also embedded directly in the notebook).
- `requirements.txt` — Python dependencies.

## How to deploy the live dashboard (needed for the "live Dashboard Link" in the report)
1. Create a GitHub repo, push `app.py`, `shopease_sample_2500.csv`, and `requirements.txt`.
2. Go to https://share.streamlit.io -> "New app" -> point it at `app.py` in that repo -> Deploy.
3. Copy the resulting `https://<yourapp>.streamlit.app` URL into the notebook's "Live Dashboard" link
   (top of `FBDA_2026_Project_ShopEase.ipynb`) and into your report submission.

## How to open the notebook with live data/dashboard links in Colab
1. Go to https://colab.research.google.com -> Upload notebook -> select `FBDA_2026_Project_ShopEase.ipynb`.
2. Upload `shopease_raw_orders.csv` and `stats_helpers.py` to the Colab session (left sidebar -> Files -> Upload),
   or mount Google Drive and adjust the path in the data-loading cell.
3. Run all cells (Runtime -> Run all) to regenerate every result live — every number in the notebook already
   matches a real run of this exact pipeline (seed = 95105107109), so re-running should reproduce it exactly.
4. Add your Colab notebook's "Share" link and the deployed Streamlit URL wherever the submission form asks for them.

## Before submitting
- Fill in Appendix 1 (Individual Contribution) honestly.
- Add/expand Appendix 2 (AI Prompt Logs) with any further prompts your group used.
- Fill in your Section (K or L) in the Project Information block.
- Double-check Prakriti Sharma's roll number — `075095` was inferred from the `075xxx` pattern of the other
  three members from "07095"; correct it everywhere (Group ID, seed, notebook, README) if it's different.
