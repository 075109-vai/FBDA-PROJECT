"""
Lightweight OLS / Logistic regression with statsmodels-style inference
(coefficients, std errors, t/z-stats, p-values, R^2), built on numpy/scipy
since statsmodels is unavailable in this environment.
"""
import numpy as np
from scipy import stats


class OLSResult:
    def __init__(self, X, y, feature_names):
        n, k = X.shape  # k includes intercept column
        Xt_X_inv = np.linalg.pinv(X.T @ X)
        beta = Xt_X_inv @ X.T @ y
        y_hat = X @ beta
        resid = y - y_hat
        sse = float(resid @ resid)
        sst = float(((y - y.mean()) ** 2).sum())
        r2 = 1 - sse / sst
        adj_r2 = 1 - (1 - r2) * (n - 1) / (n - k)
        sigma2 = sse / (n - k)
        cov_beta = sigma2 * Xt_X_inv
        se = np.sqrt(np.diag(cov_beta))
        t_stats = beta / se
        p_vals = 2 * (1 - stats.t.cdf(np.abs(t_stats), df=n - k))
        f_stat = (r2 / (k - 1)) / ((1 - r2) / (n - k)) if k > 1 else np.nan
        f_p = 1 - stats.f.cdf(f_stat, k - 1, n - k) if k > 1 else np.nan

        self.n, self.k = n, k
        self.feature_names = feature_names
        self.coef = dict(zip(feature_names, beta))
        self.se = dict(zip(feature_names, se))
        self.t = dict(zip(feature_names, t_stats))
        self.p = dict(zip(feature_names, p_vals))
        self.r2, self.adj_r2 = float(r2), float(adj_r2)
        self.f_stat, self.f_p = float(f_stat), float(f_p)
        self.resid = resid
        self.y_hat = y_hat

    def to_dict(self):
        return {
            'n': self.n, 'r2': self.r2, 'adj_r2': self.adj_r2,
            'f_stat': self.f_stat, 'f_p': self.f_p,
            'coefficients': {
                name: {'coef': float(self.coef[name]), 'se': float(self.se[name]),
                       't': float(self.t[name]), 'p': float(self.p[name])}
                for name in self.feature_names
            }
        }


def fit_ols(X_df, y):
    """X_df: pandas DataFrame of predictors (numeric, already dummy-encoded if needed)."""
    X = np.column_stack([np.ones(len(X_df))] + [X_df[c].values.astype(float) for c in X_df.columns])
    names = ['Intercept'] + list(X_df.columns)
    return OLSResult(X, y.values.astype(float), names)


class LogitResult:
    """Newton-Raphson logistic regression with Wald-test inference."""
    def __init__(self, X, y, feature_names, max_iter=100, tol=1e-8):
        n, k = X.shape
        beta = np.zeros(k)
        for _ in range(max_iter):
            z = X @ beta
            p = 1 / (1 + np.exp(-z))
            W = p * (1 - p)
            W = np.clip(W, 1e-8, None)
            grad = X.T @ (y - p)
            H = -(X.T * W) @ X
            step = np.linalg.solve(H, grad)
            beta_new = beta - step
            if np.max(np.abs(beta_new - beta)) < tol:
                beta = beta_new
                break
            beta = beta_new
        z = X @ beta
        p = 1 / (1 + np.exp(-z))
        W = np.clip(p * (1 - p), 1e-8, None)
        cov = np.linalg.inv((X.T * W) @ X)
        se = np.sqrt(np.diag(cov))
        z_stats = beta / se
        p_vals = 2 * (1 - stats.norm.cdf(np.abs(z_stats)))

        # McFadden pseudo R^2
        ll_full = np.sum(y * np.log(p + 1e-12) + (1 - y) * np.log(1 - p + 1e-12))
        p_null = y.mean()
        ll_null = np.sum(y * np.log(p_null + 1e-12) + (1 - y) * np.log(1 - p_null + 1e-12))
        pseudo_r2 = 1 - ll_full / ll_null

        self.n, self.k = n, k
        self.feature_names = feature_names
        self.coef = dict(zip(feature_names, beta))
        self.se = dict(zip(feature_names, se))
        self.z = dict(zip(feature_names, z_stats))
        self.p = dict(zip(feature_names, p_vals))
        self.pseudo_r2 = float(pseudo_r2)

    def to_dict(self):
        return {
            'n': self.n, 'pseudo_r2': self.pseudo_r2,
            'coefficients': {
                name: {'coef': float(self.coef[name]), 'se': float(self.se[name]),
                       'z': float(self.z[name]), 'p': float(self.p[name]),
                       'odds_ratio': float(np.exp(self.coef[name]))}
                for name in self.feature_names
            }
        }


def fit_logit(X_df, y):
    X = np.column_stack([np.ones(len(X_df))] + [X_df[c].values.astype(float) for c in X_df.columns])
    names = ['Intercept'] + list(X_df.columns)
    return LogitResult(X, y.values.astype(float), names)
